
``` 
1) bu nedir?
------------------------------
selam dostum, bu sitenin bir yerinde, bizim discord sunucusu icin ihtiyacin olan davet linki var.

2) adam gibi linki versenize niye kastiriyorsunuz?
------------------------------
e ne guzel iste, yeni bir eglence yeni bir bilmece yaptik, 
kotu mu ettik. hem zaten cok kolay... yaparsin...

3) Link i buldum, davet gecersiz diyor?
------------------------------
bulmussun dogru ama davet o degil ;) kurcala bakalim o buldugunu, kolay gelsin.

4) ugrasamayacagim bunlarla girmiyecegim ben...
------------------------------
ok.

5) sunucuya girmenin baska bir yolu yok mu? arkadasimiz icerideyse alsa falan?
------------------------------
aslinda var, twitch aboneleri ve youtube katil'imcilari discord un kendilerine tanidiklari 
bir haktan faydalanabilirler, aslinda onu engellemek istedik ama elimizden pek bisey gelmedi.

6) diyelim obur turlu girdik sunucuya, abonelik bitince atilcaz mi?
------------------------------
hayir tabiki, paragoz oldugumuz icin yapmiyoruz bunu. iceride olan herkes, kurallara uydugu, 
akilli davrandigi ve aktif oldugu surece iceride kalir.

7) aktif oldugu surece mi? o ne demek?
------------------------------
soyleki, mesela son 1.5 yil icerisinde, sunucunun "genel" kanalinda bir nokta bile yazmamis, 
hic bisey yapmadiysa bile, bir "gunaydin" dememis kisi, aslinda bu topluluk icin 
bir arti deger uretmiyor demektir. o zaman kendisine rahatsizlik vermemek adina 
ufak bir tik "kick" leyebiliyoruz kendilerini ;) 

8) inaktiflikten kicklendik diyelim bir daha giremiyor muyuz?
------------------------------
yok canim olurmu oyle sey, kapi her zaman acik. acikca kural ihlali yapip 
banlanmadiginiz surece girebilirsiniz.

9) peki itirazimiz var, yada teknik bir sorun yasadik ne yapacagiz?
------------------------------
twitch de yayina gelebilirsiniz (insta veya twitter dan duyuruyorum yayinlari) 
orada moderator arkadaslara DM atabilirsiniz, kendileri size yardimci olur.

10) sunucudan haksiz yere banlandim, ne bicim modlariniz var, simdi hemen twitter da, 
instagram da sana mesaj aticam, olmadi mail aticam, dov o modlari benim icin...
------------------------------
tamam. ama sonuc genelde degismez, bir yanlislik varsa yayina gel modlara DM at, sunucuyu ben yonetmiyorum.

UNUTMAYIN, bu bir oyun, kimse kimseyi bir sinava tabi tutmuyor, burada amac eglenmek ve ogrenmek. 
umarim bu aciklama yeterli olmustur ;) sitem etmenize gerek yok, eglenmeye calisin lutfen.
sevgiler,
```

<!--- aradigin bu olabilir mi ?== Rz7n2nt7FR== --->

